%% ------------------------------------------------------------------

% Solar Activity Optimizer (SAO)
%  Developed in MATLAB R2024b (2025.5.13)  
% %  Author and programmer:                                                               %
% Zexuan Pei

%% -------------------------------------------------------------------

 function [Best_FF,Best_P,conv]=SAO(N,T,LB,UB,Dim,F_obj)
Best_P=zeros(1,Dim);
Best_FF=inf;


X=initialization(N,Dim,UB,LB);
Xnew=X;
Ffun=zeros(1,size(X,1));
Ffun_new=zeros(1,size(Xnew,1));
velocities = zeros(N, Dim);


E_crit = 100;         % 耀斑触发能量阈值
flare_decay = 0.95;   % 耀斑强度衰减系数
   theta = 2*pi*rand();
        
r0_init = norm(UB - LB)/2;
 b = log(1.618)/(pi/2); % 黄金螺旋

t=1;

r0 = r0_init * exp(-5*t/T);
spiral = r0 * exp(b*theta) * cos(theta);

 % 1. 太阳黑子周期参数调整
    alpha = 0.5 * (1 + 0.2*sin(2*pi*t/T)); % 周期性震荡


% 2. 计算当前磁能（种群分散度）
    
while t<T+1
    for i=1:size(X,1)
        F_UB=X(i,:)>UB;
        F_LB=X(i,:)<LB;
        X(i,:)=(X(i,:).*(~(F_UB+F_LB)))+UB.*F_UB+LB.*F_LB;
        Ffun(1,i)=F_obj(X(i,:));
        if Ffun(1,i)<Best_FF
            Best_FF=Ffun(1,i);
            Best_P=X(i,:);
        end
    end
    
        %-------------------------------------------------------------------------------------
    for i=1:size(X,1)
        %-------------------------------------------------------------------------------------
         % if randn <0.5
             
              Xnew(i,:)= Best_P(1,:) *alpha + randn() * abs( Best_P(1,:)- X(i,:));  % 经典测试函数效果好，但CEC不行
               
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
         
                %-------------------------------------------------------------------------------------
           
           
               Xnew(i,:) = X((floor(N*rand()+1)),:) *alpha +randn () * abs( X((floor(N*rand()+1)),:)- X(i,:)); %经典效果好
              
              
              Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
        %  else
          %  Xnew(i,:)= Best_P(1,:) + rand () *  abs( Best_P(1,:)- X(i,:));  % cec效果好，但经典测试函数不行
          % 
          %  Ffun_new(1,i)=F_obj(Xnew(i,:));
          %       if Ffun_new(1,i)<Ffun(1,i)
          %           X(i,:)=Xnew(i,:);
          %           Ffun(1,i)=Ffun_new(1,i);
          %       end
          % 
          %  Xnew(i,:) = X((floor(N*rand()+1)),:)  + rand ()*abs( X((floor(N*rand()+1)),:)- X(i,:)); % cec 效果好
          %     Ffun_new(1,i)=F_obj(Xnew(i,:));
          %       if Ffun_new(1,i)<Ffun(1,i)
          %           X(i,:)=Xnew(i,:);
          %           Ffun(1,i)=Ffun_new(1,i);
          %       end
          % 
          % end
           
           %-------------------------------------------------------------------------------------
         

         
           E = sum(vecnorm( X(i,:)-  Best_P(1,:), 2, 2).^2);
   if E > E_crit
        P_flare = 1 - exp(-E/E_crit); % 耀斑触发概率
        flare_particles = rand(N,1) < P_flare;

        % 耀斑动力学：定向突变
        flare_strength = 0.1 * flare_decay^t;
        for i = find(flare_particles)' 

            direction = sign( Best_P(1,:)- X(i,:));
            velocities(i,:) = velocities(i,:).*rand + flare_strength * direction .* (1 + randn(1,Dim)*0.1);
        end

    end

              %   Xnew(i,:) = X(i,:) + velocities(i,:);

                              
                  Xnew(i,:) =   Best_P(1,:)+ velocities(i,:);
        
                % Xnew(i,:) = ((mean(X(i,:))+Best_P(1,:)))./2+ velocities(i,:);

                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
          
                %-------------------------------------------------------------------------------------
               
                  Xnew(i,:) = X(i,:) + spiral;
                
             
                Ffun_new(1,i)=F_obj(Xnew(i,:));
                if Ffun_new(1,i)<Ffun(1,i)
                    X(i,:)=Xnew(i,:);
                    Ffun(1,i)=Ffun_new(1,i);
                end
           
    end
    %-------------------------------------------------------------------------------------
    if mod(t,100)==0
        display(['At iteration ', num2str(t), ' the best solution fitness is ', num2str(Best_FF)]);
    end
    conv(t)=Best_FF;
    t=t+1;
end


 end

function X=initialization(N,Dim,UB,LB)

B_no= size(UB,2); % numnber of boundaries

if B_no==1
    X=rand(N,Dim).*(UB-LB)+LB;
end

if B_no>1
    for i=1:Dim
        Ub_i=UB(i);
        Lb_i=LB(i);
        X(:,i)=rand(N,1).*(Ub_i-Lb_i)+Lb_i;
    end
    end
end

