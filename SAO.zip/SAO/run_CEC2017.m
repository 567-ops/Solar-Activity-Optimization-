
%% ------------------------------------------------------------------

% Solar Activity Optimizer (SAO)
%  Developed in MATLAB R2024b (2025.5.13)  
% %  Author and programmer:                                                               %
% Zexuan Pei   NCWU

%%
clc

clear all 
close all
dim = 10; % ��ѡ 2, 10, 30, 50, 100



 Function_name=2 ;
% 
% F_name=Function_name;

%% cec2022
%%  ѡ����
% Function_name=5; % �������� 1 - 12
% [lb,ub,dim,fobj] = Get_Functions_cec2022(Function_name,dim);
% 



Max_iter=500;
Solution_no=30;  
nPop=Solution_no;
%%   ������Ժ���
% F_name='F23';    
% 
% [LB,UB,Dim,F_obj]=Get_F(F_name); 
% %[Best_FF,Best_P,conv, exp_ana,search_history]=AO(Solution_no,Max_iter,LB,UB,Dim,F_obj); 
% 
% 
% [Best_FF,Best_P,conv]=SAO(Solution_no,Max_iter,LB,UB,Dim,F_obj); 
%%  CEC ���Ժ���



F_name=Function_name;

[lb,ub,dim,fobj] = Get_Functions_cec2017(F_name,dim);


[Best_score,Best_pos,cg_curve]=SAO(nPop,Max_iter,lb,ub,dim,fobj);

% conv=cg_curve;

Best_P=Best_pos;
Best_FF=Best_score;
F_name=Function_name;
%% 
Function_name=F_name;



%cg_curve=conv;

Best_pos= Best_P;
Best_score=Best_FF;
% 
% %% CEC��ͼ
% 
% %% plot
% figure('Position',[400 200 300 250])
% semilogy(conv,'Color','r','Linewidth',1)
% %     plot(cg_curve,'Color','r','Linewidth',1)
% title(['Convergence curve, Dim=' num2str(dim)])
% xlabel('Iteration');
% ylabel(['Best score F' num2str(F_name) ]);
% axis tight
% grid on
% box on
% set(gca,'color','none')
% legend('SAO')
% 
% display(['The best-obtained solution by SAO is : ', num2str(Best_P)]);
% display(['The best optimal values of the objective funciton found by SAO is : ', num2str(Best_FF)]);
% 
% 
% 
%  conv1=conv';









% plot
figure('Position',[400 200 300 250])
semilogy(cg_curve,'Color','r','Linewidth',1)
   % plot(cg_curve,'Color','r','Linewidth',1)
title(['Convergence curve, Dim=' num2str(dim)])
xlabel('Iteration');
ylabel(['Best score F' num2str(Function_name) ]);
axis tight
grid on
box on
set(gca,'color','none')
legend('SAO')

display(['The best-obtained solution by SAO is : ', num2str(Best_pos)]);
display(['The best optimal values of the objective funciton found by SAO is : ', num2str(Best_score)]);


