%_______________________________________________________________________________________%
%  Aquila Optimizer (AO) source codes (version 1.0)                                     %
%                                                                                       %
%  Developed in MATLAB R2015a (7.13)                                                    %
%  Author and programmer: Laith Abualigah                                               %
%  Abualigah, L, Yousri, D, Abd Elaziz, M, Ewees, A, Al-qaness, M, Gandomi, A.          %
%         e-Mail: Aligah.2020@gmail.com                                                 %
%       Homepage:                                                                       %
%         1- https://scholar.google.com/citations?user=39g8fyoAAAAJ&hl=en               %
%         2- https://www.researchgate.net/profile/Laith_Abualigah                       %
%                                                                                       %
%   Main paper:                                                                         %
%_____________Aquila Optimizer: A novel meta-heuristic optimization algorithm___________%
%_______________________________________________________________________________________%
% Abualigah, L, Yousri, D, Abd Elaziz, M, Ewees, A, Al-qaness, M, Gandomi, A. (2021). 
% Aquila Optimizer: A novel meta-heuristic optimization algorithm. 
% Computers & Industrial Engineering.
%_______________________________________________________________________________________%






function [LB,UB,Dim,F_obj] = Get_F(F)



switch F
    case 'F1'
        F_obj = @F1;
        LB=-100;
        UB=100;
        Dim =10;

    case 'F2'
        F_obj = @F2;
        LB=-10;
        UB=10;
        Dim = 10;        
    case 'F3'
        F_obj = @F3;
        LB=-100;
        UB=100;
        Dim = 10;        
    case 'F4'
        F_obj = @F4;
        LB=-100;
        UB=100;
        Dim = 10;        
    case 'F5'
        F_obj = @F5;
        LB=-30;
        UB=30;
        Dim = 10;        
    case 'F6'
        F_obj = @F6;
        LB=-100;
        UB=100;
        Dim = 10;        
    case 'F7'
        F_obj = @F7;
        LB=-1.28;
        UB=1.28;
        Dim = 10;        
    case 'F8'
        F_obj = @F8;
        LB=-500;
        UB=500;
        Dim = 10;        
    case 'F9'
        F_obj = @F9;
        LB=-5.12;
        UB=5.12;
        Dim = 10;        
    case 'F10'
        F_obj = @F10;
        LB=-32;
        UB=32;
        Dim = 10;        
    case 'F11'
        F_obj = @F11;
        LB=-600;
        UB=600;
        Dim = 10;        
    case 'F12'
        F_obj = @F12;
        LB=-50;
        UB=50;
        Dim = 10;        
    case 'F13'
        F_obj = @F13;
        LB=-50;
        UB=50;
        Dim = 10;        
    case 'F14'
        F_obj = @F14;
        LB=-65.536;
        UB=65.536;
        Dim=2;

    case 'F15'
        F_obj = @F15;
        LB=-5;
        UB=5;
        Dim=4;

    case 'F16'
        F_obj = @F16;
        LB=-5;
        UB=5;
        Dim=2;

    case 'F17'
        F_obj = @F17;
        LB=[-5,0];
        UB=[10,15];
        Dim=2;

    case 'F18'
        F_obj = @F18;
        LB=-2;
        UB=2;
        Dim=2;

    case 'F19'
        F_obj = @F19;
        LB=0;
        UB=1;
        Dim=3;

    case 'F20'
        F_obj = @F20;
        LB=0;
        UB=1;
        Dim=6;     

    case 'F21'
        F_obj = @F21;
        LB=0;
        UB=10;
        Dim=4;    

    case 'F22'
        F_obj = @F22;
        LB=0;
        UB=10;
        Dim=4;    

    case 'F23'
        F_obj = @F23;
        LB=0;
        UB=10;
        Dim=4;

%% 焊接梁设计问题(Welded beam design)
case 'F54'
       
    F_obj = @F54;

 LB =0.10;
  UB=10;

       % LB = [0.10; 0.10; 0.10; 0.10];  % 下界
       %  UB = [2; 10; 10; 2];    
        Dim = 4;
        
    %% 压缩弹簧设计问题(Compression spring design)
    case 'F55'
        F_obj = @F55;
        LB =0.05;
        
        UB=15;
        % LB = [0.05; 0.25; 2.00];   % 下界
        % UB = [2.00; 1.30; 15.0];        % 上界
        Dim = 3;
        
    %% 压力容器设计问题(Pressure vessel design)
    case 'F56'
        F_obj = @F56;
        LB=0;
        UB=200;
        
        
        
        % LB = [0; 0; 10; 10];           % 下界
        % UB = [99; 99; 200; 200];        % 上界
        Dim = 4;
        
    %% 轮系设计问题(Gear train design)
    case 'F57'
        F_obj = @F57;

        LB=12;
        UB=60;
        % LB = [12; 12; 12; 12];           % 下界
        % UB = [60; 60; 60; 60];        % 上界
        Dim = 4;
        
    %% 减速器设计问题(Speed reducer design)
    case 'F58'
        F_obj = @F58;
        LB=0.7;
        UB=28;
        % LB = [2.6; 0.7; 17; 7.3; 7.3; 2.9; 5];
        % UB = [3.6; 0.8; 28; 8.3; 8.3; 3.9; 5.5];
        Dim = 7;
        
    %% 管柱设计问题(Tabular column design)
    case 'F59'
        F_obj = @F59;
        % LB = [2; 0.2];
        % UB = [14; 0.8];
        LB=0.2;
        UB=14;
        Dim = 2;
        
    %% 最小化工字梁问题的垂直挠度问题(Minimize the vertical deflection of an I-beam problem)
    case 'F60'
        F_obj = @F60;
        % LB = [10; 10; 0.9; 0.9];
        % UB = [80; 50; 5.0; 5.0];
        LB=0.9;
        UB=80;
        Dim = 4;
        
    %% 三杆桁架设计问题(Three bar truss design)
    case 'F61'
        F_obj = @F61;
        % LB = [0; 0];
        % UB = [1; 1];
        LB=0;
        UB=1;
        Dim = 2;
  
    %% 悬臂梁设计问题(Cantilever beam design)
    case 'F62'
        F_obj = @F62;
        % LB = [0.01; 0.01; 0.01; 0.01; 0.01];
        % UB = [100; 100; 100; 100; 100];
        LB=0.01;
        UB=100;
        Dim = 5;
        
    %% 活塞杆优化问题(Piston lever)
    case 'F63'
        F_obj = @F63;
        % LB = [0.05; 0.05; 0.05; 0.05];
        % UB = [500; 500; 500; 120];
        LB=0.05;
        UB=500;
        Dim = 4;
        
    %% 槽形舱壁设计问题(Corrugated bulkhead design)
    case 'F64'
        F_obj = @F64;
        % LB = [0; 0; 0; 0];
        % UB = [100; 100; 100; 5];
          LB=0;
          UB=100;
        Dim = 4;
        
    %% 汽车侧面碰撞设计问题(Car side impact design)
    case 'F65'
        F_obj = @F65;
        % LB = [0.50; 0.50; 0.50; 0.50; 0.50; 0.50; 0.50; 0; 0; -30; -30];
        % UB = [1.50; 1.50; 1.50; 1.50; 1.50; 1.50; 1.50; 1; 1; +30; +30];
        LB=-30;
        UB=30;
        Dim = 11;
        
    %% 钢筋混凝土梁设计问题(A reinforced concrete beam design)
    case 'F66'
        F_obj = @F66;
        % LB = [0; 0; 5];
        % UB = [1; 1; 10];
        LB=0;
        UB=10;
        Dim = 3;






end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F1

function o = F1(x)
o=sum(x.^2);
end

% F2

function o = F2(x)
o=sum(abs(x))+prod(abs(x));
end

% F3

function o = F3(x)
dim=size(x,2);
o=0;
for i=1:dim
    o=o+sum(x(1:i))^2;
end
end

% F4

function o = F4(x)
o=max(abs(x));
end

% F5

function o = F5(x)
dim=size(x,2);
o=sum(100*(x(2:dim)-(x(1:dim-1).^2)).^2+(x(1:dim-1)-1).^2);
end

% F6

function o = F6(x)
o=sum(abs((x+.5)).^2);
end

% F7

function o = F7(x)
dim=size(x,2);
o=sum([1:dim].*(x.^4))+rand;
end

% F8

function o = F8(x)
o=sum(-x.*sin(sqrt(abs(x))));
end

% F9

function o = F9(x)
dim=size(x,2);
o=sum(x.^2-10*cos(2*pi.*x))+10*dim;
end

% F10

function o = F10(x)
dim=size(x,2);
o=-20*exp(-.2*sqrt(sum(x.^2)/dim))-exp(sum(cos(2*pi.*x))/dim)+20+exp(1);
end

% F11

function o = F11(x)
dim=size(x,2);
o=sum(x.^2)/4000-prod(cos(x./sqrt([1:dim])))+1;
end

% F12

function o = F12(x)
dim=size(x,2);
o=(pi/dim)*(10*((sin(pi*(1+(x(1)+1)/4)))^2)+sum((((x(1:dim-1)+1)./4).^2).*...
(1+10.*((sin(pi.*(1+(x(2:dim)+1)./4)))).^2))+((x(dim)+1)/4)^2)+sum(Ufun(x,10,100,4));
end

% F13

function o = F13(x)
dim=size(x,2);
o=.1*((sin(3*pi*x(1)))^2+sum((x(1:dim-1)-1).^2.*(1+(sin(3.*pi.*x(2:dim))).^2))+...
((x(dim)-1)^2)*(1+(sin(2*pi*x(dim)))^2))+sum(Ufun(x,5,100,4));
end

% F14

function o = F14(x)
aS=[-32 -16 0 16 32 -32 -16 0 16 32 -32 -16 0 16 32 -32 -16 0 16 32 -32 -16 0 16 32;,...
-32 -32 -32 -32 -32 -16 -16 -16 -16 -16 0 0 0 0 0 16 16 16 16 16 32 32 32 32 32];

for j=1:25
    bS(j)=sum((x'-aS(:,j)).^6);
end
o=(1/500+sum(1./([1:25]+bS))).^(-1);
end

% F15

function o = F15(x)
aK=[.1957 .1947 .1735 .16 .0844 .0627 .0456 .0342 .0323 .0235 .0246];
bK=[.25 .5 1 2 4 6 8 10 12 14 16];bK=1./bK;
o=sum((aK-((x(1).*(bK.^2+x(2).*bK))./(bK.^2+x(3).*bK+x(4)))).^2);
end

% F16

function o = F16(x)
o=4*(x(1)^2)-2.1*(x(1)^4)+(x(1)^6)/3+x(1)*x(2)-4*(x(2)^2)+4*(x(2)^4);
end

% F17

function o = F17(x)
o=(x(2)-(x(1)^2)*5.1/(4*(pi^2))+5/pi*x(1)-6)^2+10*(1-1/(8*pi))*cos(x(1))+10;
end

% F18

function o = F18(x)
o=(1+(x(1)+x(2)+1)^2*(19-14*x(1)+3*(x(1)^2)-14*x(2)+6*x(1)*x(2)+3*x(2)^2))*...
    (30+(2*x(1)-3*x(2))^2*(18-32*x(1)+12*(x(1)^2)+48*x(2)-36*x(1)*x(2)+27*(x(2)^2)));
end

% F19

function o = F19(x)
aH=[3 10 30;.1 10 35;3 10 30;.1 10 35];cH=[1 1.2 3 3.2];
pH=[.3689 .117 .2673;.4699 .4387 .747;.1091 .8732 .5547;.03815 .5743 .8828];
o=0;
for i=1:4
    o=o-cH(i)*exp(-(sum(aH(i,:).*((x-pH(i,:)).^2))));
end
end

% F20

function o = F20(x)
aH=[10 3 17 3.5 1.7 8;.05 10 17 .1 8 14;3 3.5 1.7 10 17 8;17 8 .05 10 .1 14];
cH=[1 1.2 3 3.2];
pH=[.1312 .1696 .5569 .0124 .8283 .5886;.2329 .4135 .8307 .3736 .1004 .9991;...
.2348 .1415 .3522 .2883 .3047 .6650;.4047 .8828 .8732 .5743 .1091 .0381];
o=0;
for i=1:4
    o=o-cH(i)*exp(-(sum(aH(i,:).*((x-pH(i,:)).^2))));
end
end

% F21

function o = F21(x)
aSH=[4 4 4 4;1 1 1 1;8 8 8 8;6 6 6 6;3 7 3 7;2 9 2 9;5 5 3 3;8 1 8 1;6 2 6 2;7 3.6 7 3.6];
cSH=[.1 .2 .2 .4 .4 .6 .3 .7 .5 .5];

o=0;
for i=1:5
    o=o-((x-aSH(i,:))*(x-aSH(i,:))'+cSH(i))^(-1);
end
end

% F22

function o = F22(x)
aSH=[4 4 4 4;1 1 1 1;8 8 8 8;6 6 6 6;3 7 3 7;2 9 2 9;5 5 3 3;8 1 8 1;6 2 6 2;7 3.6 7 3.6];
cSH=[.1 .2 .2 .4 .4 .6 .3 .7 .5 .5];

o=0;
for i=1:7
    o=o-((x-aSH(i,:))*(x-aSH(i,:))'+cSH(i))^(-1);
end
end

% F23

function o = F23(x)
aSH=[4 4 4 4;1 1 1 1;8 8 8 8;6 6 6 6;3 7 3 7;2 9 2 9;5 5 3 3;8 1 8 1;6 2 6 2;7 3.6 7 3.6];
cSH=[.1 .2 .2 .4 .4 .6 .3 .7 .5 .5];

o=0;
for i=1:10
    o=o-((x-aSH(i,:))*(x-aSH(i,:))'+cSH(i))^(-1);
end
end

function o=Ufun(x,a,k,m)
o=k.*((x-a).^m).*(x>a)+k.*((-x-a).^m).*(x<(-a));
end


function PHI = F54(x)
P = 6000;                         % 末端载荷 APPLIED TIP LOAD
E = 30e6;                         % 梁的杨氏模量 YOUNGS MODULUS OF BEAM
G = 12e6;                        % 梁的剪切模量 SHEAR MODULUS OF BEAM
tem = 14;                        % 梁的悬臂部分长度 LENGTH OF CANTILEVER PART OF BEAM
TAUMAX = 13600;           % 最大允许切应力 MAXIMUM ALLOWED SHEAR STRESS
SIGMAX = 30000;            % 最大允许弯曲应力 MAXIMUM ALLOWED BENDING STRESS
DELTMAX = 0.25;             % 最大允许弯曲载荷 MAXIMUM ALLOWED TIP DEFLECTION
% 范围




M =  P*(tem+x(2)/2);        % 焊接点处的弯矩 BENDING MOMENT AT WELD POINT
R = sqrt((x(2)^2)/4+((x(1)+x(3))/2)^2);                         % 一些常数 SOME CONSTANT
J =  2*(sqrt(2)*x(1)*x(2)*((x(2)^2)/4+((x(1)+x(3))/2)^2)); % 极惯性矩 POLAR MOMENT OF INERTIA
PHI =  1.10471*x(1)^2*x(2)+0.04811*x(3)*x(4)*(14+x(2)); % 目标函数 OBJECTIVE FUNCTION
SIGMA = (6*P*tem)/(x(4)*x(3)^2);             % 弯曲应力 BENDING STRESS
DELTA = (4*P*tem^3)/(E*x(3)^3*x(4));      % 末端偏差 TIP DEFLECTION
PC = 4.013*E*sqrt((x(3)^2*x(4)^6)/36)*(1-x(3)*sqrt(E/(4*G))/(2*tem))/(tem^2); % 弯曲载荷 BUCKLING LOAD
TAUP =  P/(sqrt(2)*x(1)*x(2));  % 切应力的一阶导数 1ST DERIVATIVE OF SHEAR STRESS
TAUPP = (M*R)/J;                  % 切应力的二阶导数 2ND DERIVATIVE OF SHEAR STRESS
TAU = sqrt(TAUP^2+2*TAUP*TAUPP*x(2)/(2*R)+TAUPP^2); % 切应力 SHEAR STRESS
G(1) = TAU-TAUMAX;         % 最大切应力约束 MAX SHEAR STRESS CONSTRAINT
G(2) =  SIGMA-SIGMAX;     % 最大弯曲应力约束 MAX BENDING STRESS CONSTRAINT
%G3 = L(1)-L(4);                % 焊缝覆盖约束 WELD COVERAGE CONSTRAINT
G(3) = DELTA-DELTMAX;
G(4) = x(1)-x(4);
G(5) = P-PC;
G(6) = 0.125-x(1);
%G4 = 0.10471*L(1)^2+0.04811*L(3)*L(4)*(14+L(2))-5; % 最大成本约束 MAX COST CONSTRAINT
%G5 =  0.125-L(1);               % 最大焊缝厚度约束 MAX WELD THICKNESS CONSTRAINT
%G6 =  DELTA-DELTMAX;   % 最大末端偏差约束 MAX TIP DEFLECTION CONSTRAINT
%G7 =  P-PC;                      % 弯曲载荷约束 BUCKLING LOAD CONSTRAINT
G(7) = 1.10471*x(1)^2+0.04811*x(3)*x(4)*(14+x(2))-5;
h = 0;
% 罚函数
PCONST = [1 1 4 0.001 1 0.5 1 1];
PHI = PHI + sum(PCONST.*max(0, [G h]));
end

% F25

function PHI = F55(x)
fit = (x(3)+2)*x(2)*(x(1)^2);
G(1) = 1-(x(2)^3*x(3))/(71785*x(1)^4);
G(2) = (4*x(2)^2-x(1)*x(2))/(12566*(x(2)*x(1)^3-x(1)^4))+1/(5108*x(1)^2)-1;
G(3) = 1-(140.45*x(1))/(x(2)^2*x(3));
G(4) = ((x(1)+x(2))/1.5)-1;
% 罚函数
PCONST = [3 4 0.1 0.1 1];
h = 0;
PHI = fit + sum(PCONST.*max(0, [G h]));
end

% F26

function PHI = F56(x)
fit = 0.6224*x(1)*x(3)*x(4)+ 1.7781*x(2)*x(3)^2 + 3.1661 *x(1)^2*x(4) + 19.84 * x(1)^2*x(3);
G(1) = -x(1)+ 0.0193*x(3);
G(2) = -x(2) + 0.00954* x(3);
G(3) = -pi*x(3)^2*x(4)-(4/3)* pi*x(3)^3 +1296000;
G(4) = x(4) - 240;
% 罚函数
PCONST = [12000 8000 1 1 1];
h = 0;
PHI = fit + sum(PCONST.*max(0, [G, h]));
end

% F27

function PHI = F57(x)
x = round(x);
fit = (1/6.931-x(3)*x(2)/(x(1)*x(4)))^2;
G(1) = 0;
G(2) = 0;
G(3) = 0;
% 罚函数
PCONST = [1 1 1 1];
h = 0;
PHI = fit + sum(PCONST.*max(0, [G, h]));
end

% F28

function PHI = F58(x)
% 目标函数
fit = 0.7854*x(1).*x(2)^2.*(3.3333*x(3)^2+14.9334*x(3)-43.0934)-1.508*x(1)*(x(6)^2+x(7)^2).....
    +7.477*(x(6)^3+x(7)^3)+0.7854*(x(4).*x(6)^2+x(5)*x(7)^2);
% 约束
g(1) = -x(1)*x(2)^2*x(3)+27;
g(2) = -x(1)*x(2)^2*x(3)^2+397.5;
g(3) = -x(2)*x(6)^4*x(3)*x(4)^(-3)+1.93;
g(4) = -x(2)*x(7)^4*x(3)/x(5)^3+1.93;
g(5) = 10*x(6)^(-3)*sqrt(16.91*10^6+(745*x(4)/(x(2)*x(3)))^2)-1100;
g(6) = 10*x(7)^(-3)*sqrt(157.5*10^6+(745*x(5)/(x(2)*x(3)))^2)-850;
g(7) = x(2)*x(3)-40;
g(8) = -x(1)/x(2)+5;
g(9) = x(1)/x(2)-12;
g(10) = 1.5*x(6)-x(4)+1.9;
g(11) = 1.1*x(7)-x(5)+1.9;
% 罚函数
PCONST = [50 10 1 1 1 20 1 300 1 1 50 1];
h = 0;
PHI = fit + sum(PCONST.*max(0, [g, h]));
end

% F29

function PHI = F59(x)
% 目标函数
fit = 9.8*x(1)*x(2)+2*x(1);
% 约束
g(1) = 1.59-x(1)*x(2);
g(2) = 47.4-x(1)*x(2)*(x(1)^2+x(2)^2);
g(3) = 2/x(1)-1;
g(4) = x(1)/14-1;
g(5) = 2/x(1)-1;
g(6) = x(1)/8-1;
% 罚函数
PCONST = [100 1 1 1 1 1 1];
h = 0;
PHI = fit + sum(PCONST.*max(0, [g, h]));
end

% F30

function PHI = F60(x)
% 目标函数
term1 = x(3)*(x(1)-2*x(4))^3/12;
term2 = x(2)*x(4)^3/6; 
term3 = 2*x(2)*x(4)*((x(1)-x(4))/2)^2;
fit = 5000/(term1+term2+term3);
% 约束
g(1) = 2*x(2)*x(4)+x(3)*(x(1)-2*x(4))-300;
term1 = x(3)*(x(1)-2*x(4))^3;
term2 = 2*x(2)*x(4)*(4*x(4)^2+3*x(1)*(x(1)-2*x(4)));
term3 = (x(1)-2*x(4))*x(3)^3;
term4 = 2*x(4)*x(2)^3;
g(2) = ((18*x(1)*10^4)/(term1+term2))+((15*x(2)*10^3)/(term3+term4))-6;
% 罚函数
PCONST = 0.1*[1 1 1];
h = 0;
PHI = fit + sum(PCONST.*max(0, [g, h]));
end

% F31

function PHI = F61(x)
% 目标函数
fit = (2*sqrt(2)*x(1)+x(2))*100;
% 约束
g(1) = (sqrt(2)*x(1)+x(2))/(sqrt(2)*x(1)^2+2*x(1)*x(2))*2-2;
g(2) = x(2)/(sqrt(2)*x(1)^2+2*x(1).*x(2))*2-2;
g(3) = 1/(sqrt(2)*x(2)+x(1))*2-2;
% 罚函数
PCONST = [140 7 15 1];
h = 0;
PHI = fit + sum(PCONST.*max(0, [g, h]));
end

% F32

function PHI = F62(x)
% 目标函数
fit = 0.0624*(x(1)+x(2)+x(3)+x(4)+x(5));
% 约束
g(1) = (61/x(1)^3)+(37/x(2)^3)+(19/x(3)^3)+(7/x(4)^3)+(1/x(5)^3)-1;
% 罚函数
PCONST = [10 1];
h = 0;
PHI = fit + sum(PCONST.*max(0, [g, h]));
end

% F33

function PHI = F63(x)
% 目标函数
teta = 0.25*pi; H = x(1); B = x(2); D = x(3); X = x(4);
l2 = ((X*sin(teta)+H)^2+(B-X*cos(teta))^2)^0.5;
l1 = ((X-B)^2+H^2)^0.5;
fit = 0.25*pi*D^2*(l2-l1);
% 约束
teta = 0.25*pi; H = x(1); B = x(2); D = x(3); X = x(4);
P = 1500; Q = 10000; L = 240; Mmax = 1.8e+6;
R = abs(-X*(X*sin(teta)+H)+H*(B-X*cos(teta)))/sqrt((X-B)^2+H^2);
F = 0.25*pi*P*D^2;
l2 = ((X*sin(teta)+H)^2+(B-X*cos(teta))^2)^0.5;
l1 = ((X-B)^2+H^2)^0.5;
g(1) = Q*L*cos(teta)-R*F;
g(2) = Q*(L-X)-Mmax;
g(3) = 1.2*(l2-l1)-l1;
g(4) = 0.5*D-B;
% 罚函数
PCONST = [1 1 1 100 1];
h = 0;
PHI = fit + sum(PCONST.*max(0, [g, h]));
end

% F34

function PHI = F64(x)
% 目标函数
b = x(1); h = x(2); l = x(3); t = x(4); ABD = abs(l^2-h^2);
fit = (5.885*t*(b+l))/(b+(abs(l^2-h^2))^0.5);
% 约束
g(1) = -t*h*(0.4*b+l/6)+8.94*(b+(ABD)^0.5);
g(2) = -t*h^2*(0.2*b+l/12)+2.2*(8.94*(b+(ABD)^0.5))^(4/3);
g(3) = -t+0.0156*b+0.15;
g(4) = -t+0.0156*l+0.15;
g(5) = -t+1.05;
g(6) = -l+h;
% 罚函数
PCONST = [1 1 3 3 100 1 1];
h = 0;
PHI = fit + sum(PCONST.*max(0, [g, h]));
end

% F35

function PHI = F65(x)
% Sections
Sec8 = [0.192 0.345];
Sec9 = [0.192 0.345];
nSec8 = numel(Sec8);
nSec9 = numel(Sec9);
x(8) = Sec8(min(floor(x(8)*nSec8+1),nSec8));
x(9) = Sec8(min(floor(x(9)*nSec9+1),nSec9));
% Objective
fit = 1.98+4.90*x(1)+6.67*x(2)+6.98*x(3)+4.01*x(4)+1.78*x(5)+2.73*x(7);
% Subjective
Fa =1.16-0.3717*x(2)*x(4)-0.00931*x(2)*x(10)-0.484*x(3)*x(9)+0.01343*x(6)*x(10);
VCu =0.261-0.0159*x(1)*x(2)-0.188*x(1)*x(8)-0.019*x(2)*x(7)+0.0144*x(3)*x(5)+0.0008757*x(5)*x(10)+0.08045*x(6)*x(9)+0.00139*x(8)*x(11)+0.00001575*x(10)*x(11);
VCm =0.214+0.00817*x(5)-0.131*x(1)*x(8)-0.0704*x(1)*x(9)+0.03099*x(2)*x(6)-0.018*x(2)*x(7)+0.0208*x(3)*x(8)+0.121*x(3)*x(9)-0.00364*x(5)*x(6)+0.0007715*x(5)*x(10)-0.0005354*x(6)*x(10)+0.00121*x(8)*x(11)+0.00184*x(9)*x(10)-0.02*x(2)^2;
VCl=0.74-0.61*x(2)-0.163*x(3)*x(8)+0.001232*x(3)*x(10)-0.166*x(7)*x(9)+0.227*x(2)^(2);
Dur=28.98+3.818*x(3)-4.2*x(1)*x(2)+0.0207*x(5)*x(10)+6.63*x(6)*x(9)-7.7*x(7)*x(8)+0.32*x(9)*x(10);
Dmr=33.86+2.95*x(3)+0.1792*x(10)-5.057*x(1)*x(2)-11*x(2)*x(8)-0.0215*x(5)*x(10)-9.98*x(7)*x(8)+22*x(8)*x(9);
Dlr=46.36-9.9*x(2)-12.9*x(1)*x(8)+0.1107*x(3)*x(10);
Fp=4.72-0.5*x(4)-0.19*x(2)*x(3)-0.0122*x(4)*x(10)+0.009325*x(6)*x(10)+0.000191*x(11)^(2);
VMBP=10.58-0.674*x(1)*x(2)-1.95*x(2)*x(8)+0.02054*x(3)*x(10)-0.0198*x(4)*x(10)+0.028*x(6)*x(10);
VFD=16.45-0.489*x(3)*x(7)-0.843*x(5)*x(6)+0.0432*x(9)*x(10)-0.0556*x(9)*x(11)-0.000786*x(11)^(2);
g = [Fa-1, VCu-0.32, VCm-0.32, VCl-0.32, Dur-32, Dmr-32, Dlr-32, Fp-4, VMBP-9.9, VFD-15.7];
% 罚函数
PCONST = [1 1 1 1 1 1 10 29.8 2 6 1];
h = 0;
PHI = fit + sum(PCONST.*max(0, [g, h]));
end

% F36

function PHI = F66(x)
% Beam Design Params
x1 = [6 6.16 6.32 6.6 7 7.11 7.2 7.8 7.9 8 8.4];
nx1 = numel(x1);
x2 = 28:40;
nx2 = numel(x2);
As = x1(min(floor(x(1)*nx1+1), nx1));
b = x2(min(floor(x(2)*nx2+1), nx2));
h = x(3);
% Objective
fit = 29.4*As+0.6*b*h;
% Subjectives
g(1) = b/h-4;
g(2) = 180+7.375*As^2/h-As*b;
% 罚函数
PCONST = [50 30 1];
h = 0;
PHI = fit + sum(PCONST.*max(0, [g, h]));
end





%%

%% 47个测试函数

% function [lb,ub,dim,fobj] = Get_F(F)
% switch F
%     case 'F1'
%         fobj = @F1;
%         limit=[-32.768,32.768];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F2'
%         fobj = @F2;
%         % limit=[-15,-5];
%         dim = 2;
%         lb = [-15,-3];
%         ub= [-5,3];
% 
%     case 'F3'
%         fobj = @F3;
%         limit=[-10, 10];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F4'
%         fobj = @F4;
%         limit=[-5.12, 5.12];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F5'
%         fobj = @F5;
%         limit= [-512, 512];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F6'
%         fobj = @F6;
%         limit=[0.5, 2.5];
%         dim = 1;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F7'
%         fobj = @F7;
%         limit=[-600, 600];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F8'
%         fobj = @F8;
%         limit= [-10, 10];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F9'
%         fobj = @F9;
%         limit= [0, 10];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F10'
%         fobj = @F10;
%         limit= [-10, 10];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F11'
%         fobj = @F11;
%         limit= [-10, 10];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F12'
%         fobj = @F12;
%         limit=[-5.12, 5.12];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F13'
%         fobj = @F13;
%         limit= [-100, 100];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F14'
%         fobj = @F14;
%         limit= [-100, 100];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F15'
%         fobj = @F15;
%         limit=[-500, 500];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F16'
%         fobj = @F17;
%         limit= [-10, 10];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F17'
%         fobj = @F17;
%         limit= [-100, 100];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F18'
%         fobj = @F18;
%         limit=[-10,10];
%         dim = 10;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F19'
%         fobj = @F19;
%         limit= [-65.536, 65.536];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F20'
%         fobj = @F20;
%         limit= [-5.12, 5.12];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F21'
%         fobj = @F21;
%         limit=[-1,1];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F22'
%         fobj = @F22;
%         limit=[-10,10];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
% 
%     case 'F23'
%         fobj = @F23;
%         limit=[-30^2,30^2];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F24'
%         fobj = @F24;
%         limit=[-10,10];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F25'
%         fobj = @F25;
%         limit=[-10,10];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F26'
%         fobj = @F26;
%         % limit=[-10,10];
%         dim = 2;
%         lb =[-1.5,-3];
%         ub= [4,4];
%     case 'F27'
%         fobj = @F27;
%         limit=[0,30];
%         dim = 4;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F28'
%         fobj = @F28;
%         limit=[-5,10];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F29'
%         fobj = @F29;
%         limit=[-5,5];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F30'
%         fobj = @F30;
%         % limit=[-10,10];
%         dim = 2;
%         lb =[-3,-2];
%         ub= [3,2];
%     case 'F31'
%         fobj = @F31;
%         limit=[-10,10];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F32'
%         fobj = @F32;
%         limit=[-5,10];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F33'
%         fobj = @F33;
%         limit=[-65.536, 65.536];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F34'
%         fobj = @F34;
%         limit=[-100,100];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F35'
%         fobj = @F35;
%         limit=[0,pi];
%         dim = 10;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F36'
%         fobj = @F36;
%         limit= [-4.5, 4.5];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F37'
%         fobj = @F37;
%         dim = 2;
%         lb =[-5,0];
%         ub= [10,15];
%     case 'F38'
%         fobj = @F38;
%         limit=[-10,10];
%         dim = 4;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F39'
%         fobj = @F39;
%         limit=[0,1];
%         dim = 1;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F40'
%         fobj = @F40;
%         limit=[-2,2];
%         dim = 2;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F41'
%         fobj = @F41;
%         limit=[0,1];
%         dim = 3;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F42'
%         fobj = @F42;
%         limit=[0,1];
%         dim = 4;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F43'
%         fobj = @F43;
%         limit=[0,1];
%         dim = 6;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F44'
%         fobj = @F44;
%         limit=[-10,10];
%         dim = 10;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F45'
%         fobj = @F45;
%         limit=[-4,5];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F46'
%         fobj = @F46;
%         limit=[0,10];
%         dim = 4;
%         lb = limit(1);
%         ub= limit(2);
%     case 'F47'
%         fobj = @F47;
%         limit=[-5,5];
%         dim = 30;
%         lb = limit(1);
%         ub= limit(2);
% end
% 
% end
% 
% % F1
% 
% function y = F1(xx)
% d = length(xx);
% 
% if (nargin < 4)
%     c = 2*pi;
% end
% if (nargin < 3)
%     b = 0.2;
% end
% if (nargin < 2)
%     a = 20;
% end
% 
% sum1 = 0;
% sum2 = 0;
% for ii = 1:d
% 	xi = xx(ii);
% 	sum1 = sum1 + xi^2;
% 	sum2 = sum2 + cos(c*xi);
% end
% 
% term1 = -a * exp(-b*sqrt(sum1/d));
% term2 = -exp(sum2/d);
% 
% y = term1 + term2 + a + exp(1);
% 
% end
% 
% % F2
% 
% function y = F2(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% term1 = 100 * sqrt(abs(x2 - 0.01*x1^2));
% term2 = 0.01 * abs(x1+10);
% 
% y = term1 + term2;
% end
% 
% % F3
% 
% function y = F3(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% fact1 = sin(x1)*sin(x2);
% fact2 = exp(abs(100 - sqrt(x1^2+x2^2)/pi));
% 
% y = -0.0001 * (abs(fact1*fact2)+1)^0.1;
% 
% end
% 
% % F4
% 
% function y = F4(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% 
% frac1 = 1 + cos(12*sqrt(x1^2+x2^2));
% frac2 = 0.5*(x1^2+x2^2) + 2;
% 
% y = -frac1/frac2;
% 
% end
% 
% % F5
% 
% function y = F5(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% term1 = -(x2+47) * sin(sqrt(abs(x2+x1/2+47)));
% term2 = -x1 * sin(sqrt(abs(x1-(x2+47))));
% 
% y = term1 + term2;
% end
% 
% % F6
% 
% function y = F6(xx)
% term1 = sin(10*pi*xx) / (2*xx);
% term2 = (xx-1)^4;
% 
% y = term1 + term2;
% 
% end
% 
% % F7
% 
% function y = F7(xx)
% d = length(xx);
% sum = 0;
% prod = 1;
% 
% for ii = 1:d
% 	xi = xx(ii);
% 	sum = sum + xi^2/4000;
% 	prod = prod * cos(xi/sqrt(ii));
% end
% 
% y = sum - prod + 1;
% end
% 
% % F8
% 
% function y = F8(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% fact1 = sin(x1)*cos(x2);
% fact2 = exp(abs(1 - sqrt(x1^2+x2^2)/pi));
% 
% y = -abs(fact1*fact2);
% end
% 
% % F9
% 
% function y = F9(xx)
% d = length(xx);
% 
% if (nargin < 2)
%     m = 5;
% end
% 
% if (nargin < 3)
%     if (m == 5)
%         c = [1, 2, 5, 2, 3];
%     else
%         error('Value of the m-dimensional vector c is required.')
%     end
% end
% 
% if (nargin < 4)
%     if (m==5 && d==2)
%         A = [3, 5; 5, 2; 2, 1; 1, 4; 7, 9];
%     else
%         error('Value of the (mxd)-dimensional matrix A is required.')
%     end
% end
% 
% outer = 0;
% for ii = 1:m
%     inner = 0;
%     for jj = 1:d
%         xj = xx(jj);
%         Aij = A(ii,jj);
%         inner = inner + (xj-Aij)^2;
%     end
%     new = c(ii) * exp(-inner/pi) * cos(pi*inner);
%     outer = outer + new;
% end
% 
% y = outer;
% end
% 
% % F10
% 
% function y = F10(xx)
% d = length(xx);
% 
% for ii = 1:d
% 	w(ii) = 1 + (xx(ii) - 1)/4;
% end
% 
% term1 = (sin(pi*w(1)))^2;
% term3 = (w(d)-1)^2 * (1+(sin(2*pi*w(d)))^2);
% 
% sum = 0;
% for ii = 1:(d-1)
% 	wi = w(ii);
%         new = (wi-1)^2 * (1+10*(sin(pi*wi+1))^2);
% 	sum = sum + new;
% end
% 
% y = term1 + sum + term3;
% end
% 
% % F11
% 
% function y = F11(xx)
% 
% x1 = xx(1);
% x2 = xx(2);
% 
% term1 = (sin(3*pi*x1))^2;
% term2 = (x1-1)^2 * (1+(sin(3*pi*x2))^2);
% term3 = (x2-1)^2 * (1+(sin(2*pi*x2))^2);
% 
% y = term1 + term2 + term3;
% end
% 
% % F12
% 
% function y = F12(xx)
% d = length(xx);
% sum = 0;
% for ii = 1:d
% 	xi = xx(ii);
% 	sum = sum + (xi^2 - 10*cos(2*pi*xi));
% end
% 
% y = 10*d + sum;
% end
% 
% % F13
% 
% function y = F13(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% fact1 = (sin(x1^2-x2^2))^2 - 0.5;
% fact2 = (1 + 0.001*(x1^2+x2^2))^2;
% 
% y = 0.5 + fact1/fact2;
% end
% 
% % F14
% 
% function y = F14(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% fact1 = (cos(sin(abs(x1^2-x2^2))))^2 - 0.5;
% fact2 = (1 + 0.001*(x1^2+x2^2))^2;
% 
% y = 0.5 + fact1/fact2;
% end
% 
% % F15
% 
% function y = F15(xx)
% d = length(xx);
% sum = 0;
% for ii = 1:d
% 	xi = xx(ii);
% 	sum = sum + xi*sin(sqrt(abs(xi)));
% end
% 
% y = 418.9829*d - sum;
% end
% 
% % F16
% 
% function y = F16(xx)
% x1 = xx(1);
% x2 = xx(2);
% sum1 = 0;
% sum2 = 0;
% 
% for ii = 1:5
% 	new1 = ii * cos((ii+1)*x1+ii);
% 	new2 = ii * cos((ii+1)*x2+ii);
% 	sum1 = sum1 + new1;
% 	sum2 = sum2 + new2;
% end
% 
% y = sum1 * sum2;
% end
% 
% % F17
% 
% function y = F17(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% term1 = x1^2;
% term2 = 2*x2^2;
% term3 = -0.3 * cos(3*pi*x1);
% term4 = -0.4 * cos(4*pi*x2);
% 
% y = term1 + term2 + term3 + term4 + 0.7;
% end
% 
% % F18
% 
% function y = F18(xx)
% if (nargin == 1)
%     b = 10;
% end
% 
% d = length(xx);
% outer = 0;
% 
% for ii = 1:d
% 	inner = 0;
% 	for jj = 1:d
% 		xj = xx(jj);
%         inner = inner + (jj+b)*(xj^ii-(1/jj)^ii);
% 	end
% 	outer = outer + inner^2;
% end
% 
% y = outer;
% end
% 
% % F19
% 
% function y = F19(xx)
% 
% d = length(xx);
% outer = 0;
% 
% for ii = 1:d
%     inner = 0;
%     for jj = 1:ii
%         xj = xx(jj);
%         inner = inner + xj^2;
%     end
%     outer = outer + inner;
% end
% 
% y = outer;
% 
% end
% 
% % F20
% 
% function y = F20(xx)
% 
% d = length(xx);
% sum = 0;
% for ii = 1:d
% 	xi = xx(ii);
% 	sum = sum + xi^2;
% end
% 
% y = sum;
% end
% 
% % F21
% 
% function y = F21(xx)
% d = length(xx);
% sum = 0;
% 
% for ii = 1:d
%     xi = xx(ii);
%     new = (abs(xi))^(ii+1);
%     sum = sum + new;
% end
% 
% y = sum;
% end
% 
% % F22
% 
% function y = F22(xx)
% d = length(xx);
% sum = 0;
% for ii = 1:d
% 	xi = xx(ii);
% 	sum = sum + ii*xi^2;
% end
% 
% y = sum;
% 
% end
% 
% % F23
% 
% function y = F23(xx)
% d = length(xx);
% sum1 = (xx(1)-1)^2;
% sum2 = 0;
% 
% for ii = 2:d
% 	xi = xx(ii);
% 	xold = xx(ii-1);
% 	sum1 = sum1 + (xi-1)^2;
% 	sum2 = sum2 + xi*xold;
% end
% 
% y = sum1 - sum2;
% end
% 
% 
% function y = F24(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% term1 = (x1 + 2*x2 - 7)^2;
% term2 = (2*x1 + x2 - 5)^2;
% 
% y = term1 + term2;
% 
% 
% end
% 
% function y = F25(xx)
% 
% x1 = xx(1);
% x2 = xx(2);
% 
% term1 = 0.26 * (x1^2 + x2^2);
% term2 = -0.48*x1*x2;
% 
% y = term1 + term2;
% 
% end
% 
% function y = F26(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% term1 = sin(x1 + x2);
% term2 = (x1 - x2)^2;
% term3 = -1.5*x1;
% term4 = 2.5*x2;
% 
% y = term1 + term2 + term3 + term4 + 1;
% 
% end
% 
% function y = F27(xx)
% 
% d = length(xx);
% 
% if (nargin == 1)
%     if (d == 4)
%         b = [8, 18, 44, 114];
%     else
%         error('Value of the d-dimensional vector b is required.')
%     end
% end
% 
% outer = 0;
% 
% for ii = 1:d
%     inner = 0;
%     for jj = 1:d
%         xj = xx(jj);
%         inner = inner + xj^ii;
%     end
%     outer = outer + (inner-b(ii))^2;
% end
% 
% y = outer;
% end
% 
% function y = F28(xx)
% d = length(xx);
% sum1 = 0;
% sum2 = 0;
% 
% for ii = 1:d
% 	xi = xx(ii);
% 	sum1 = sum1 + xi^2;
% 	sum2 = sum2 + 0.5*ii*xi;
% end
% 
% y = sum1 + sum2^2 + sum2^4;
% 
% end
% 
% function y = F29(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% term1 = 2*x1^2;
% term2 = -1.05*x1^4;
% term3 = x1^6 / 6;
% term4 = x1*x2;
% term5 = x2^2;
% 
% y = term1 + term2 + term3 + term4 + term5;
% 
% end
% 
% function y = F30(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% term1 = (4-2.1*x1^2+(x1^4)/3) * x1^2;
% term2 = x1*x2;
% term3 = (-4+4*x2^2) * x2^2;
% 
% y = term1 + term2 + term3;
% 
% end
% 
% function y = F31(xx)
% 
% x1 = xx(1);
% d = length(xx);
% term1 = (x1-1)^2;
% 
% sum = 0;
% for ii = 2:d
% 	xi = xx(ii);
% 	xold = xx(ii-1);
% 	new = ii * (2*xi^2 - xold)^2;
% 	sum = sum + new;
% end
% 
% y = term1 + sum;
% 
% end
% 
% function y = F32(xx)
% 
% d = length(xx);
% sum = 0;
% for ii = 1:(d-1)
% 	xi = xx(ii);
% 	xnext = xx(ii+1);
% 	new = 100*(xnext-xi^2)^2 + (xi-1)^2;
% 	sum = sum + new;
% end
% 
% y = sum;
% end
% 
% function y = F33(xx)
% x1 = xx(1);
% x2 = xx(2);
% sum = 0;
% 
% A = zeros(2, 25);
% a = [-32, -16, 0, 16, 32];
% A(1, :) = repmat(a, 1, 5);
% ar = repmat(a, 5, 1);
% ar = ar(:)';
% A(2, :) = ar;
% 
% for ii = 1:25
%     a1i = A(1, ii);
%     a2i = A(2, ii);
%     term1 = ii;
%     term2 = (x1 - a1i)^6;
%     term3 = (x2 - a2i)^6;
%     new = 1 / (term1+term2+term3);
%     sum = sum + new;
% end
% 
% y = 1 / (0.002 + sum);
% 
% end
% 
% function y = F34(xx)
% 
% x1 = xx(1);
% x2 = xx(2);
% 
% fact1 = -cos(x1)*cos(x2);
% fact2 = exp(-(x1-pi)^2-(x2-pi)^2);
% 
% y = fact1*fact2;
% 
% end
% 
% function y = F35(xx)
% 
% if (nargin == 1)
%     m = 10;
% end
% 
% d = length(xx);
% sum = 0;
% 
% for ii = 1:d
% 	xi = xx(ii);
% 	new = sin(xi) * (sin(ii*xi^2/pi))^(2*m);
% 	sum  = sum + new;
% end
% 
% y = -sum;
% end
% 
% function y = F36(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% term1 = (1.5 - x1 + x1*x2)^2;
% term2 = (2.25 - x1 + x1*x2^2)^2;
% term3 = (2.625 - x1 + x1*x2^3)^2;
% 
% y = term1 + term2 + term3;
% 
% end
% 
% function y = F37(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% if (nargin < 7)
%     t = 1 / (8*pi);
% end
% if (nargin < 6)
%     s = 10;
% end
% if (nargin < 5)
%     r = 6;
% end
% if (nargin < 4)
%     c = 5/pi;
% end
% if (nargin < 3)
%     b = 5.1 / (4*pi^2);
% end
% if (nargin < 2)
%     a = 1;
% end
% 
% term1 = a * (x2 - b*x1^2 + c*x1 - r)^2;
% term2 = s*(1-t)*cos(x1);
% 
% y = term1 + term2 + s;
% 
% end
% 
% function y = F38(xx)
% x1 = xx(1);
% x2 = xx(2);
% x3 = xx(3);
% x4 = xx(4);
% 
% term1 = 100 * (x1^2-x2)^2;
% term2 = (x1-1)^2;
% term3 = (x3-1)^2;
% term4 = 90 * (x3^2-x4)^2;
% term5 = 10.1 * ((x2-1)^2 + (x4-1)^2);
% term6 = 19.8*(x2-1)*(x4-1);
% 
% y = term1 + term2 + term3 + term4 + term5 + term6;
% 
% end
% 
% function y = F39(xx)
% 
% fact1 = (6*xx - 2)^2;
% fact2 = sin(12*xx - 4);
% 
% y = fact1 * fact2;
% end
% 
% function y = F40(xx)
% x1 = xx(1);
% x2 = xx(2);
% 
% fact1a = (x1 + x2 + 1)^2;
% fact1b = 19 - 14*x1 + 3*x1^2 - 14*x2 + 6*x1*x2 + 3*x2^2;
% fact1 = 1 + fact1a*fact1b;
% 
% fact2a = (2*x1 - 3*x2)^2;
% fact2b = 18 - 32*x1 + 12*x1^2 + 48*x2 - 36*x1*x2 + 27*x2^2;
% fact2 = 30 + fact2a*fact2b;
% 
% y = fact1*fact2;
% 
% end
% 
% function y = F41(xx)
% alpha = [1.0, 1.2, 3.0, 3.2]';
% 
% A = [3.0, 10, 30;
% 
%      0.1, 10, 35;
% 
%      3.0, 10, 30;
% 
%      0.1, 10, 35];
% 
% P = 10^(-4) * [3689, 1170, 2673;
% 
%                4699, 4387, 7470;
% 
%                1091, 8732, 5547;
% 
%                381, 5743, 8828];
% 
% 
% 
% outer = 0;
% 
% for ii = 1:4
% 
% 	inner = 0;
% 
% 	for jj = 1:3
% 
% 		xj = xx(jj);
% 
% 		Aij = A(ii, jj);
% 
% 		Pij = P(ii, jj);
% 
% 		inner = inner + Aij*(xj-Pij)^2;
% 
% 	end
% 
% 	new = alpha(ii) * exp(-inner);
% 
% 	outer = outer + new;
% 
% end
% 
% 
% 
% y = -outer;
% 
% end
% 
% function y = F42(xx)
% alpha = [1.0, 1.2, 3.0, 3.2]';
% A = [10, 3, 17, 3.5, 1.7, 8;
%      0.05, 10, 17, 0.1, 8, 14;
%      3, 3.5, 1.7, 10, 17, 8;
%      17, 8, 0.05, 10, 0.1, 14];
% P = 10^(-4) * [1312, 1696, 5569, 124, 8283, 5886;
%                2329, 4135, 8307, 3736, 1004, 9991;
%                2348, 1451, 3522, 2883, 3047, 6650;
%                4047, 8828, 8732, 5743, 1091, 381];
% 
% outer = 0;
% for ii = 1:4
% 	inner = 0;
% 	for jj = 1:4
% 		xj = xx(jj);
% 		Aij = A(ii, jj);
% 		Pij = P(ii, jj);
% 		inner = inner + Aij*(xj-Pij)^2;
% 	end
% 	new = alpha(ii) * exp(-inner);
% 	outer = outer + new;
% end
% 
% y = (1.1 - outer) / 0.839;
% 
% end
% 
% function y = F43(xx)
% alpha = [1.0, 1.2, 3.0, 3.2]';
% A = [10, 3, 17, 3.5, 1.7, 8;
%      0.05, 10, 17, 0.1, 8, 14;
%      3, 3.5, 1.7, 10, 17, 8;
%      17, 8, 0.05, 10, 0.1, 14];
% P = 10^(-4) * [1312, 1696, 5569, 124, 8283, 5886;
%                2329, 4135, 8307, 3736, 1004, 9991;
%                2348, 1451, 3522, 2883, 3047, 6650;
%                4047, 8828, 8732, 5743, 1091, 381];
% 
% outer = 0;
% for ii = 1:4
% 	inner = 0;
% 	for jj = 1:6
% 		xj = xx(jj);
% 		Aij = A(ii, jj);
% 		Pij = P(ii, jj);
% 		inner = inner + Aij*(xj-Pij)^2;
% 	end
% 	new = alpha(ii) * exp(-inner);
% 	outer = outer + new;
% end
% 
% y = -(2.58 + outer) / 1.94;
% 
% end
% 
% function y = F44(xx)
% if (nargin == 1)
%     b = 0.5;
% end
% 
% d = length(xx);
% outer = 0;
% 
% for ii = 1:d
% 	inner = 0;
% 	for jj = 1:d
% 		xj = xx(jj);
%         inner = inner + (jj^ii+b)*((xj/jj)^ii-1);
%     end
% 	outer = outer + inner^2;
% end
% 
% y = outer;
% 
% end
% 
% function y = F45(xx)
% d = length(xx);
% sum = 0;
% 
% for ii = 1:(d/4)
% 	term1 = (xx(4*ii-3) + 10*xx(4*ii-2))^2;
% 	term2 = 5 * (xx(4*ii-1) - xx(4*ii))^2;
% 	term3 = (xx(4*ii-2) - 2*xx(4*ii-1))^4;
% 	term4 = 10 * (xx(4*ii-3) - xx(4*ii))^4;
% 	sum = sum + term1 + term2 + term3 + term4;
% end
% 
% y = sum;
% 
% end
% 
% function y = F46(xx)
% m = 10;
% b = 0.1 * [1, 2, 2, 4, 4, 6, 3, 7, 5, 5]';
% C = [4.0, 1.0, 8.0, 6.0, 3.0, 2.0, 5.0, 8.0, 6.0, 7.0;
%      4.0, 1.0, 8.0, 6.0, 7.0, 9.0, 3.0, 1.0, 2.0, 3.6;
%      4.0, 1.0, 8.0, 6.0, 3.0, 2.0, 5.0, 8.0, 6.0, 7.0;
%      4.0, 1.0, 8.0, 6.0, 7.0, 9.0, 3.0, 1.0, 2.0, 3.6];
% 
% outer = 0;
% for ii = 1:m
% 	bi = b(ii);
% 	inner = 0;
% 	for jj = 1:4
% 		xj = xx(jj);
% 		Cji = C(jj, ii);
% 		inner = inner + (xj-Cji)^2;
% 	end
% 	outer = outer + 1/(inner+bi);
% end
% 
% y = -outer;
% end
% 
% function y = F47(xx)
% d = length(xx);
% sum = 0;
% for ii = 1:d
% 	xi = xx(ii);
% 	new = xi^4 - 16*xi^2 + 5*xi;
% 	sum = sum + new;
% end
% 
% y = sum/2;
% end
% function o=Ufun(x,a,k,m)
% o=k.*((x-a).^m).*(x>a)+k.*((-x-a).^m).*(x<(-a));
% end
